Core/Src/sai.o: ../Core/Src/sai.c ../Core/Inc/sai.h \
 ../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal.h \
 ../Core/Inc/stm32h7xx_hal_conf.h \
 ../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_rcc.h \
 ../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_def.h \
 ../Drivers/CMSIS/Device/ST/STM32H7xx/Include/stm32h7xx.h \
 ../Drivers/CMSIS/Device/ST/STM32H7xx/Include/stm32h750xx.h \
 ../Drivers/CMSIS/Include/core_cm7.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Include/mpu_armv7.h \
 ../Drivers/CMSIS/Device/ST/STM32H7xx/Include/system_stm32h7xx.h \
 ../Drivers/STM32H7xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_rcc_ex.h \
 ../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_gpio.h \
 ../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_gpio_ex.h \
 ../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_dma.h \
 ../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_dma_ex.h \
 ../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_mdma.h \
 ../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_exti.h \
 ../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_cortex.h \
 ../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_adc.h \
 ../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_ll_adc.h \
 ../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_adc_ex.h \
 ../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_flash.h \
 ../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_flash_ex.h \
 ../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_hsem.h \
 ../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_i2c.h \
 ../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_i2c_ex.h \
 ../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_pwr.h \
 ../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_pwr_ex.h \
 ../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_sai.h \
 ../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_sai_ex.h \
 ../Drivers/BSP/Components/wm8994/wm8994.h \
 ../Drivers/BSP/Components/wm8994/wm8994_reg.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/BSP/stm32h750b_dk/stm32h750b_discovery_bus.h \
 ../Drivers/BSP/stm32h750b_dk/stm32h750b_discovery_conf.h \
 ../Drivers/BSP/stm32h750b_dk/stm32h750b_discovery_errno.h \
 ../Drivers/BSP/stm32h750b_dk/stm32h750b_discovery_errno.h
../Core/Inc/sai.h:
../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal.h:
../Core/Inc/stm32h7xx_hal_conf.h:
../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_rcc.h:
../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_def.h:
../Drivers/CMSIS/Device/ST/STM32H7xx/Include/stm32h7xx.h:
../Drivers/CMSIS/Device/ST/STM32H7xx/Include/stm32h750xx.h:
../Drivers/CMSIS/Include/core_cm7.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Include/mpu_armv7.h:
../Drivers/CMSIS/Device/ST/STM32H7xx/Include/system_stm32h7xx.h:
../Drivers/STM32H7xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_rcc_ex.h:
../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_gpio.h:
../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_gpio_ex.h:
../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_dma.h:
../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_dma_ex.h:
../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_mdma.h:
../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_exti.h:
../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_cortex.h:
../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_adc.h:
../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_ll_adc.h:
../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_adc_ex.h:
../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_flash.h:
../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_flash_ex.h:
../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_hsem.h:
../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_i2c.h:
../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_i2c_ex.h:
../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_pwr.h:
../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_pwr_ex.h:
../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_sai.h:
../Drivers/STM32H7xx_HAL_Driver/Inc/stm32h7xx_hal_sai_ex.h:
../Drivers/BSP/Components/wm8994/wm8994.h:
../Drivers/BSP/Components/wm8994/wm8994_reg.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/BSP/stm32h750b_dk/stm32h750b_discovery_bus.h:
../Drivers/BSP/stm32h750b_dk/stm32h750b_discovery_conf.h:
../Drivers/BSP/stm32h750b_dk/stm32h750b_discovery_errno.h:
../Drivers/BSP/stm32h750b_dk/stm32h750b_discovery_errno.h:
